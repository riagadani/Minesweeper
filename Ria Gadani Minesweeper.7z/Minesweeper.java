import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
public class Minesweeper extends JPanel implements ActionListener, MouseListener{
    JFrame frame;
    JMenuBar mBar;
    JMenu game, icons, controls;
    JMenuItem beg, intermediate, expert, original, sweet, brick;
    JPanel scoreboard, gridBoard, buttonBoard, tColor, mColor, tBackground, mBackground;
    GridLayout layout;
    JLabel time, mines;
    JButton reset;
    ImageIcon smile, flag, blank, box, mine, lose, win, click;
    ImageIcon one, two, three, four, five, six, seven, eight;
    JToggleButton[][] grid;
    int col = 9, row = 9;
    boolean bselected = true, iselected = false, eselected = false;
    int t, m, f, selected;
    boolean start = false, playing = true;
    Timer timer;
    String theme = "original";

    GraphicsEnvironment ge;
    Font digital;
    
    
    
    public Minesweeper(){
        frame = new JFrame("Minesweeper");

        
        frame.add(this);
        frame.setSize(1000,800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        mBar = new JMenuBar();
        game = new JMenu("Game");
        icons = new JMenu("Icons");
        controls = new JMenu("Controls");
        beg = new JMenuItem("Beginner");
        intermediate = new JMenuItem("Intermediate");
        expert = new JMenuItem("Expert");
        beg.addActionListener(this);
        intermediate.addActionListener(this);
        expert.addActionListener(this);
        
        JTextArea c = new JTextArea("Left click an empty square to reveal it\n");
        c.append("Right click an empty square to flag it\n");
        c.append("Click the middle button to reset the game");
        c.setSize(new Dimension(250,100));
        c.setLineWrap(true);
        c.setEditable(false);
        controls.add(c);
        
        game.add(beg);
        game.add(intermediate);
        game.add(expert);
        mBar.add(game);
        original = new JMenuItem("Original");
        sweet = new JMenuItem("Sweet");
        brick = new JMenuItem("Bricks");
        original.addActionListener(this);
        sweet.addActionListener(this);
        brick.addActionListener(this);
        icons.add(original);
        icons.add(sweet);
        icons.add(brick);
        mBar.add(icons);
        mBar.add(controls);
        frame.setJMenuBar(mBar);

        scoreboard = new JPanel();
        scoreboard.setLayout(new GridLayout(1,3));
        scoreboard.setSize(new Dimension(frame.getWidth(), 20));
        frame.setSize(new Dimension(360,380));
        setIcons();

        try{
            ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            digital = Font.createFont(Font.TRUETYPE_FONT, new File("DS-DIGIB.TTF")).deriveFont(25f);
            ge.registerFont(digital);
        }catch (IOException |FontFormatException e){}

        time = new JLabel("000",SwingConstants.CENTER);
        mines = new JLabel("",SwingConstants.CENTER);
        time.setFont(digital);
        mines.setFont(digital);
        time.setForeground(Color.RED);
        time.setOpaque(true);
        time.setBackground(Color.BLACK);
        mines.setForeground(Color.RED);
        tColor = new JPanel();
        mColor = new JPanel();
        tBackground = new JPanel();
        mBackground = new JPanel();
        tColor.setBackground(Color.BLACK);
        tColor.add(time);
        tBackground.add(tColor);
        
        mColor.setBackground(Color.BLACK);
        mColor.add(mines);
        mBackground.add(mColor);


        buttonBoard = new JPanel();
        reset = new JButton(smile);
        reset.setPreferredSize(new Dimension(40,40));
        buttonBoard.add(reset);
        reset.addActionListener(this);
        scoreboard.add(mBackground);
        scoreboard.add(buttonBoard);
        scoreboard.add(tBackground);
        setBoard();
        frame.add(scoreboard, BorderLayout.NORTH);

        frame.setVisible(true);
    }
    public void setIcons(){

        smile = new ImageIcon("./"+theme+"/smile.png");
        smile = new ImageIcon(smile.getImage().getScaledInstance(40,40, Image.SCALE_SMOOTH));
        if(reset != null)
            reset.setIcon(smile);
        box = new ImageIcon("./"+theme+"/box.png");
        box = new ImageIcon(box.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        blank = new ImageIcon("./"+theme+"/blank.png");
        blank = new ImageIcon(blank.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        one = new ImageIcon("./"+theme+"/one.png");
        one = new ImageIcon(one.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        two = new ImageIcon("./"+theme+"/two.png");
        two = new ImageIcon(two.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        three = new ImageIcon("./"+theme+"/three.png");
        three = new ImageIcon(three.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        four = new ImageIcon("./"+theme+"/four.png");
        four = new ImageIcon(four.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        five = new ImageIcon("./"+theme+"/five.png");
        five = new ImageIcon(five.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        six = new ImageIcon("./"+theme+"/six.png");
        six = new ImageIcon(six.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        seven = new ImageIcon("./"+theme+"/seven.png");
        seven = new ImageIcon(seven.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        eight = new ImageIcon("./"+theme+"/eight.png");
        eight = new ImageIcon(eight.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-8, Image.SCALE_SMOOTH));
        flag = new ImageIcon("./"+theme+"/flag.png");
        flag.setImage(flag.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-10, Image.SCALE_SMOOTH));
        mine = new ImageIcon("./"+theme+"/mine.png");
        mine = new ImageIcon(mine.getImage().getScaledInstance(frame.getWidth()/col, frame.getHeight()/row-10, Image.SCALE_SMOOTH));
        lose = new ImageIcon("./"+theme+"/lose.png");
        lose = new ImageIcon(lose.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH));
        win = new ImageIcon("./"+theme+"/win.png");
        win = new ImageIcon(win.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH));
        click = new ImageIcon("./"+theme+"/shocked.png");
        click = new ImageIcon(click.getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH));
        
    }
    public void setBoard(){
        if(timer != null){
            timer.cancel();
            timer = new Timer();
        }
        start = false;
        playing = true;
        selected = 0;
        if(bselected){
            row = 9;
            col = 9;
            t = 0;
            m = 10;
            frame.setSize(new Dimension(360,380));
        }
        if(iselected){
            row = 16;
            col = 16;
            m = 40;
            t = 0;
            frame.setSize(new Dimension(640,660));
        }
        if(eselected){
            row = 16;
            col = 30;
            m = 99;
            t = 0;
            frame.setSize(new Dimension(1200,670));
        }
        time.setText(""+t);
        setIcons();
        f = m;
        mines.setText(""+m);
        if(gridBoard!=null)
            frame.remove(gridBoard);
        gridBoard = new JPanel();
       
        grid = new JToggleButton[row][col];
        for(int i = 0; i < row; i++){
            for(int j = 0; j < col; j++){
                grid[i][j] = new JToggleButton(box);
                grid[i][j].addMouseListener(this);
                grid[i][j].setSelectedIcon(blank);
                grid[i][j].putClientProperty("col", j);
                grid[i][j].putClientProperty("row", i);
                grid[i][j].putClientProperty("state", 0);
                grid[i][j].putClientProperty("opened", 0);
            }
        }
        layout = new GridLayout(row, col);
        gridBoard.setLayout(layout);
        for(int i = 0; i < row; i++){
            for(int j = 0; j < col; j++){
                gridBoard.add(grid[i][j]);
            }
        }
        
        frame.add(gridBoard,BorderLayout.CENTER);
        frame.revalidate();
    }
    public void setMines(JToggleButton button){
        int count = 0;
        int rb = Integer.parseInt("" + button.getClientProperty("row"));
        int cb = Integer.parseInt("" + button.getClientProperty("col"));

        while(count < m){
            int r = (int)(Math.random()*row);
            int c = (int)(Math.random()*col);
            if(Integer.parseInt(""+grid[r][c].getClientProperty("state"))!=9 && ((r != rb &&!(c>=cb-1 && c <= cb+1)) || (r != r-1 &&!(c>=cb-1 && c <= cb+1))||(r != r+1 && !(c>=cb-1 && c <= cb+1)))){
                grid[r][c].setSelectedIcon(mine);
                grid[r][c].putClientProperty("state", 9);
                count++;
            }
        }

        for(int i = 0; i < row; i++){
            for(int j = 0; j < col; j++){
                int num = 0;
                if(Integer.parseInt("" + grid[i][j].getClientProperty("state")) == 0){
                    for(int a = i-1; a <= i+1; a++){
                        for(int b = j-1; b <= j+1; b++){
                            try{
                                if(Integer.parseInt("" + grid[a][b].getClientProperty("state")) == 9)
                                    num++;
                            }catch(ArrayIndexOutOfBoundsException e){

                            }
                        }
                    }
                    grid[i][j].putClientProperty("state", num);
                }
            }
        }
        for(int i = 0; i<row; i++){
            for(int j = 0; j<col; j++){
                if(!grid[i][j].getSelectedIcon().equals(flag)){
                    switch(Integer.parseInt(""+grid[i][j].getClientProperty("state"))){
                    case 1: grid[i][j].setSelectedIcon(one);
                            break;
                    case 2: grid[i][j].setSelectedIcon(two);
                            break;
                    case 3: grid[i][j].setSelectedIcon(three);
                            break;
                    case 4: grid[i][j].setSelectedIcon(four);
                            break;
                    case 5: grid[i][j].setSelectedIcon(five);
                            break;
                    case 6: grid[i][j].setSelectedIcon(six);
                            break;
                    case 7: grid[i][j].setSelectedIcon(seven);
                            break;
                    case 8: grid[i][j].setSelectedIcon(eight);
                            break;
                    }
                } 
            }
        }

    }
    public void expand(JToggleButton button){
        int x = Integer.parseInt("" + button.getClientProperty("row"));
        int y = Integer.parseInt("" + button.getClientProperty("col"));
        button.setSelected(true);
        button.putClientProperty("opened", Integer.parseInt(""+button.getClientProperty("opened"))+1);
        if(Integer.parseInt(""+button.getClientProperty("opened")) == 1)
            selected++;
        if(Integer.parseInt("" + button.getClientProperty("state")) == 0){
            for(int i = x-1; i <= x+1; i++){
                for(int j = y-1; j <= y+1; j++){
                    try{
                        if(!grid[i][j].isSelected() && !button.getIcon().equals(flag) && Integer.parseInt("" + button.getClientProperty("state")) != 9)
                            expand(grid[i][j]);
                    }catch(ArrayIndexOutOfBoundsException e){

                    }
                }
            }
        }
    }
    public void endGame(){
        reset.setIcon(lose);
        for(int i = 0; i< row; i++){
            for(int j = 0; j < col; j++){
                
                grid[i][j].setEnabled(false);
                if(Integer.parseInt(""+grid[i][j].getClientProperty("state")) == 9){
                    grid[i][j].setDisabledIcon(mine);
                }
            }
        }
    }
    public void win(){
        System.out.println("win");
        timer.cancel();
        reset.setIcon(win);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == beg){
            bselected = true;
            iselected = false;
            eselected = false;
        }
        if(e.getSource() == intermediate){
            iselected = true;
            bselected = false;
            eselected = false;
        }
        if(e.getSource() == expert){
            eselected = true;
            bselected = false;
            iselected = false;
        }
        if(e.getSource() == reset){
            setBoard();
        }
        if(e.getSource() == original){
            theme = "original";
        }
        if(e.getSource() == sweet){
            theme = "sweet";
        }
        if(e.getSource() == brick){
            theme = "tile";
        }
        setBoard();
    }
    public void mouseClicked(MouseEvent e){
    
    }
    public void mouseEntered(MouseEvent e){
        
    }
    public void mouseExited(MouseEvent e){

    }
    public void mousePressed(MouseEvent e){
        if(((JToggleButton)e.getComponent()).isEnabled() && SwingUtilities.isLeftMouseButton(e) && !((JToggleButton)e.getComponent()).isSelected()){
            reset.setIcon(click);
        }

    }
    public void mouseReleased(MouseEvent e){
        if(playing)
            reset.setIcon(smile);
        if(!start){
            setMines((JToggleButton)e.getComponent());
            start = true;
            timer = new Timer();
            timer.schedule(new UpdateTimer(), 0, 1000);
        }
        if(((JToggleButton)e.getComponent()).isEnabled()){
            if(SwingUtilities.isRightMouseButton(e)){
                if(!((JToggleButton)e.getComponent()).isSelected()){
                    if(!((JToggleButton)e.getComponent()).getIcon().equals(flag) && f > 0){
                        ((JToggleButton)e.getComponent()).setIcon(flag);
                        ((JToggleButton)e.getComponent()).setDisabledSelectedIcon(((JToggleButton)e.getComponent()).getSelectedIcon());
                        ((JToggleButton)e.getComponent()).setSelectedIcon(flag);
                        f--;
                        mines.setText("" +f);
    
                    }
                    else{
                        ((JToggleButton)e.getComponent()).setIcon(box);
                        ((JToggleButton)e.getComponent()).setSelectedIcon(((JToggleButton)e.getComponent()).getDisabledSelectedIcon());
                        f++;
                        mines.setText(""+f);
                    }
                    
                }
    
            }else{
                if(((JToggleButton)e.getComponent()).getIcon().equals(flag)){
                    ((JToggleButton)e.getComponent()).setSelected(false);
                }else{
                    ((JToggleButton)e.getComponent()).setSelected(true);
                    if(Integer.parseInt("" +((JToggleButton)e.getComponent()).getClientProperty("state")) == 9){
                        if(SwingUtilities.isRightMouseButton(e)){
            if(!((JToggleButton)e.getComponent()).isSelected()){
                if(!((JToggleButton)e.getComponent()).getIcon().equals(flag) && f > 0){
                    ((JToggleButton)e.getComponent()).setIcon(flag);
                    ((JToggleButton)e.getComponent()).setSelectedIcon(flag);
                    f--;
                    mines.setText("" +f);

                }
                else{
                    ((JToggleButton)e.getComponent()).setIcon(box);
                    ((JToggleButton)e.getComponent()).setSelectedIcon(blank);
                    f++;
                }
                
            }

        }else{
            if(((JToggleButton)e.getComponent()).getIcon().equals(flag)){
                ((JToggleButton)e.getComponent()).setSelected(false);
            }else{
                ((JToggleButton)e.getComponent()).setSelected(true);
                if(Integer.parseInt("" +((JToggleButton)e.getComponent()).getClientProperty("state")) == 9){
                    playing = false;
                    ((JToggleButton)e.getComponent()).setSelected(false);
                    endGame();
                }else{
                    expand(((JToggleButton)e.getComponent()));
                }
            }
        }
                        playing = false;
                        endGame();
                    }else{
                        expand(((JToggleButton)e.getComponent()));
                    }
                }
            }
        }
        
        if(selected == row*col-m){
            win();
        }
    }
    public static void main(String[] args){
        Minesweeper app = new Minesweeper();
    }
    public class UpdateTimer extends TimerTask{
        public void run(){
            if(playing && t < 1000){
                t++;
                time.setText("" + t);
            }
        }
    }
}